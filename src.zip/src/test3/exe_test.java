package test3;

public class exe_test {
	public static void main(String args[]) {
		System.out.println(System.getProperty("user.dir") + "\\login_successful.exe");
		
		 
		 /*
		 Runtime run = Runtime.getRuntime();
	     Process p = null;
	     String exeFile = "";
	     
	     try{
	  	       exeFile = "D:\\ec\\work\\Soft404\\src\\test3\\login_successful.exe";
	  	     System.out.println( " sdsa" );
	  	       p = run.exec(exeFile);
	  	     System.out.println( "kjhkjh" );
	  	     }catch( Exception e ){
	  	       System.out.println( " ERROR exec" );
	  	     System.out.println( e );
	  	     }
	  	 */
		
		
		
		
		
	}

}
