package test3;

import javax.swing.*;

import java.awt.BorderLayout;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

public class Use_exe extends JFrame {
	
	JFrame w1;
	JLabel lab;
	
	public Use_exe(){} 
	
	public Use_exe(String ss) {
		init(ss);
		setBounds(860, 445, 200, 190);
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		try {
			Thread.sleep(1500);

		} catch (InterruptedException e) {
			System.out.println("error");
		}

		dispose();
	}
	
	    void init(String s){
			w1 = new JFrame("��¼�ɹ�");
			lab = new JLabel("     ��ӭ����," + s);
			lab.setFont(new java.awt.Font("����", 1, 15));
			
			add(lab, BorderLayout.CENTER); // ���ô��ڵı��� 
	    } 
	
	/*
	   JMenuBar menubar;
	    JMenu menu,subMenu;
	    JMenuItem  itemLiterature,itemCooking;
	    public Use_exe(){} 
	    public Use_exe(String s,int x,int y,int w,int h) {
	       init(s);
	       setLocation(x,y);
	       setSize(w,h);
	       setVisible(true);
	       setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
	       try {
				Thread.sleep(5500);

			} catch (InterruptedException e) {
				System.out.println("error");
			}
	       dispose();
	    }
	    void init(String s){
	       setTitle("��¼�ɹ�");             //���ô��ڵı���   
	       /*
	       menubar=new JMenuBar(); 
	       menu=new JMenu("�˵�"); 
	       subMenu=new JMenu("��������");  
	       itemLiterature=new JMenuItem("��ѧ����",new ImageIcon("a.gif"));
	       itemCooking=new JMenuItem("��⿻���",new ImageIcon("b.gif"));
	       itemLiterature.setAccelerator(KeyStroke.getKeyStroke('A')); 
	       itemCooking.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,InputEvent.CTRL_MASK)); 
	       menu.add(itemLiterature); 
	       menu.addSeparator();   //�ڲ˵�֮�����ӷָ���
	       menu.add(itemCooking); 
	       menu.add(subMenu);  
	       subMenu.add(new JMenuItem("����",new ImageIcon("c.gif"))); 
	       subMenu.add(new JMenuItem("����",new ImageIcon("d.gif")));
	       menubar.add(menu); 
	       setJMenuBar(menubar);
	       
	       
	    } */
	    
}
