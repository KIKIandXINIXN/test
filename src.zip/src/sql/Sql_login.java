package sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class Sql_login {
	String staff_admin[] = new String[10];
	String staff_password[] = new String[10];
	int staff_count = 0;
	
	String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	// ����JDBC����
	String dbURL = "jdbc:sqlserver://localhost:1434; DatabaseName=Supermarket";
	// ���ӷ����������ݿ�
	String userName = "sa"; // Ĭ���û���
	String userPwd = "123"; // ����
	Connection dbConn = null;
	
	public Sql_login(){
		try {
			Class.forName(driverName);
			dbConn = DriverManager.getConnection(dbURL, userName, userPwd);
			System.out.println("Connection Successful!");
			// ������ӳɹ� ����̨���Connection Successful!
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		/**********************���ݿ�sql����ѯ*******************************/
		Statement sql;
		ResultSet rs;
		
		try {
			sql = dbConn.createStatement();
			rs = sql.executeQuery("SELECT * FROM staff");//SQL��ѯ���
			
			while(rs.next()) {
				staff_admin[staff_count]= rs.getString(1); 
				staff_password[staff_count] = rs.getString(2);
				staff_count ++;
			}
			dbConn.close();

		} catch (SQLException e) {
			System.out.println(e);
		}
		
	}
	
	/*********************************************************/
	public boolean cheak_password(String admin,String password) {
		for (int i = 0;i< staff_count;i++) {
			if(admin.equals((staff_admin[i]).replace(" ", ""))) {
				if(password.equals((staff_password[i]).replace(" ", ""))) {
					System.out.println(admin);
					System.out.println(password);
					return true;
				}
			}
			if(i == staff_count-1){
				return false;
			}
		}
		return false;
	}
}

