package listen.Listen_page_sell_goods;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Listen_button_to_alter implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO �Զ����ɵķ������

	}

}
