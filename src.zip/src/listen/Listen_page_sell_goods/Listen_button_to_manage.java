package listen.Listen_page_sell_goods;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import page.Open_page;
import page.Page_sell_goods;

public class Listen_button_to_manage implements ActionListener {
	Page_sell_goods page_sell_goods;

	public void set_page_sell_goods(Page_sell_goods page_sell_goods) {
		this.page_sell_goods = page_sell_goods;
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO �Զ����ɵķ������
				open o = new open();
				close c = new close();
				o.start();
				c.start();
			}
			
			class open extends Thread{
				public void run() {
					Open_page openpage = new Open_page();
					openpage.page_manage_goods(); // �򿪽���
				}
			}
			
			class close extends Thread{
				public void run() {
					try {
						Thread.sleep(300);
					} catch (InterruptedException e) {
						// TODO �Զ����ɵ� catch ��
						e.printStackTrace();
					}
					page_sell_goods.window.dispose();
				}
			}

		}
