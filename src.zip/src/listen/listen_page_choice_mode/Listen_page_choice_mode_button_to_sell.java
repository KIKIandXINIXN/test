package listen.listen_page_choice_mode;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import listen.listen_page_choice_mode.Listen_page_choice_mode_button_to_manage.close;
import listen.listen_page_choice_mode.Listen_page_choice_mode_button_to_manage.open;
import page.Open_page;
import page.Page_choice_mode;

public class Listen_page_choice_mode_button_to_sell implements ActionListener {
	Page_choice_mode page_choice_mode;
	
	public void set_page_choice_mode(Page_choice_mode page_choice_mode) {
		this.page_choice_mode = page_choice_mode;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO �Զ����ɵķ������
				open o = new open();
				close c = new close();
				o.start();
				c.start();
			}
			
			class open extends Thread{
				public void run() {
					Open_page openpage = new Open_page();
					openpage.page_sell_goods(); // �򿪽���
				}
			}
			
			class close extends Thread{
				public void run() {
					try {
						Thread.sleep(300);
					} catch (InterruptedException e) {
						// TODO �Զ����ɵ� catch ��
						e.printStackTrace();
					}
					page_choice_mode.window.dispose();
				}
			}

		}
