package listen.Listen_page_manage_goods;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import page.Open_page;
import page.Page_manage_goods;


public class Listen_button_to_sell implements ActionListener{
	Page_manage_goods page_manage_goods;
	
    public void set_page_manage_goods(Page_manage_goods page_manage_goods) {
		this.page_manage_goods = page_manage_goods;
	}

	@Override
    public void actionPerformed(ActionEvent e) {
		// TODO �Զ����ɵķ������
		open o = new open();
		close c = new close();
		o.start();
		c.start();
	}
	
	class open extends Thread{
		public void run() {
			Open_page openpage = new Open_page();
			openpage.page_sell_goods(); // �򿪽���
		}
	}
	
	class close extends Thread{
		public void run() {
			try {
				Thread.sleep(300);
			} catch (InterruptedException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			page_manage_goods.window.dispose();
		}
	}

}