package listen.Listen_page_manage_goods;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import page.*;

public class Listen_button_add_goods implements ActionListener{
	Page_manage_goods page_manage_goods;
	
	public void set_page_manage_goods(Page_manage_goods page_manage_goods) {
		this.page_manage_goods = page_manage_goods;
	}
	
    @Override
    public void actionPerformed(ActionEvent e) {
		Open_page openpage = new Open_page();
		openpage.set_page_manage_goods(page_manage_goods);
		openpage.page_add_goods(); //�򿪽���
    }


 
}