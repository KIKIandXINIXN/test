package listen.Listen_page_manage_goods;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import page.Open_page;
import page.Page_manage_goods;
import sql.Sql_delete;
import sql.Sql_select;

public class Listen_button_alter_goods implements ActionListener{
	Page_manage_goods page_manage_goods;

	
	public void set_page_manage_goods(Page_manage_goods page_manage_goods) {
		this.page_manage_goods = page_manage_goods;
	}
	
    @Override
    public void actionPerformed(ActionEvent e) {
        //new Page_alter_goods();
    	if(page_manage_goods.table.getSelectedColumn()<0) {
    		JOptionPane.showMessageDialog(page_manage_goods, "��ѡ��Ҫ�޸ĵ����ݣ�");
    	}else {
    		String goods_name = page_manage_goods.table.getValueAt(page_manage_goods.table.getSelectedRow(), 2).toString().trim();
    		Object[] options ={ "��", "��" };  //�Զ��尴ť�ϵ�����
    		int judge = JOptionPane.showOptionDialog(page_manage_goods, "ȷ��Ҫ�޸ĸ���Ʒ��\r\n" + goods_name , "�޸���Ʒ",JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]); 
    		//System.out.println(judge);
    		if(judge == 0) { //0Ϊ�ǣ�1Ϊ��
    			//������
            	String goods_id1 = page_manage_goods.table.getValueAt(page_manage_goods.table.getSelectedRow(), 0).toString().trim();       	
    			//��Ʒ���
            	String goods_id2 = page_manage_goods.table.getValueAt(page_manage_goods.table.getSelectedRow(), 1).toString().trim();
            	//System.out.println(goods_id1 + " " + goods_id2);
    			Open_page openpage = new Open_page();
    			openpage.set_page_manage_goods(page_manage_goods);
    			openpage.set_goods_id1(goods_id1); //������
    			openpage.set_goods_id2(goods_id2); //��Ʒ���
    			openpage.page_alter_goods(); //�򿪽���
    			
    		}
    	}
    }
}
