package listen;

import java.awt.event.*;


//�˳�����

public class Listen_button_quit implements ActionListener {
	 public void actionPerformed(ActionEvent e) {
		 
		   System.exit(0);
	   }
}

