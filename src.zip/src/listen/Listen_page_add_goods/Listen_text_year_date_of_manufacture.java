package listen.Listen_page_add_goods;

import java.awt.event.*;
import javax.swing.*;

public class Listen_text_year_date_of_manufacture implements KeyListener, FocusListener {

	public void keyPressed(KeyEvent e) {
		JTextField t = (JTextField) e.getSource();
		if (t.getText().trim().length() >= 3) {
			t.transferFocus();
		}
	}

	public void keyTyped(KeyEvent e) {
	}

	public void keyReleased(KeyEvent e) {
	}

	public void focusGained(FocusEvent e) {

	}

	public void focusLost(FocusEvent e) {
	}

}
