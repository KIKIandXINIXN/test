package listen.Listen_page_add_goods;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JTextField;

public class Listen_text_month_or_day_date_of_manufacture implements KeyListener, FocusListener {

	public void keyPressed(KeyEvent e) {
		JTextField t = (JTextField) e.getSource();
		if (t.getText().trim().length() >= 1) {
			t.transferFocus();
		}
	}

	public void keyTyped(KeyEvent e) {
	}

	public void keyReleased(KeyEvent e) {
	}

	public void focusGained(FocusEvent e) {


	}

	public void focusLost(FocusEvent e) {
	}

}