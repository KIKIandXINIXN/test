package listen.Listen_page_add_goods;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import page.Page_add_goods;

public class Listen_page_add_goods_text_id implements ActionListener {
	Page_add_goods page_add_goods;
	String [][] message;
	String id;//��¼��Ʒ���
	int row;//��¼��Ʒ����
	
	public void set_message(String [][] message) {
    	this.message = message;
    }
	
	public void set_page_add_goods(Page_add_goods page_add_goods) {
    	this.page_add_goods = page_add_goods;
    }
	
	public void actionPerformed(ActionEvent e) {
		id = page_add_goods.text_id.getText().trim();
		
		if(check_id()) {
			System.out.println("��Ʒ���ڣ�");
			page_add_goods.text_name.setText(message[row][1].trim());
			page_add_goods.text_num.setText(message[row][2].trim());
			page_add_goods.text_price.setText(message[row][3].trim());
			page_add_goods.text_year.setText(message[row][4].trim());
			page_add_goods.text_month.setText(message[row][5].trim());
			page_add_goods.text_day.setText(message[row][6].trim());
			page_add_goods.text_expiration_day.setText(message[row][7].trim());
		}
		else {
			System.out.println("û�и���Ʒ��");
			page_add_goods.text_name.setText(null);
			page_add_goods.text_num.setText(null);
			page_add_goods.text_price.setText(null);
			page_add_goods.text_year.setText(null);
			page_add_goods.text_month.setText(null);
			page_add_goods.text_day.setText(null);
			page_add_goods.text_expiration_day.setText(null);
		}
	}
	
	public boolean check_id() {
		for(int i = 0;i < message.length;i++) {
			if(message[i][0].trim().equals(id)) {
				row = i;
				return true;
			}
		}
		return false;
	}
}
