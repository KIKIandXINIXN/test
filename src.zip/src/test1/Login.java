package test1;

import java.awt.BorderLayout;
import javax.swing.*;
import java.awt.*;

public class Login extends JFrame{
	Box boxH,boxF;								//��ʽ��
	Box boxVOne,boxVTwo,boxVThree,boxVFour;		//��ʽ��
	JButton button1,button2;
			
	public Login(){
		setLayout(new java.awt.FlowLayout());
		init();
		setTitle("��¼");
		setLocationRelativeTo(null);
		
		int width = Toolkit.getDefaultToolkit().getScreenSize().width;
	    int height = Toolkit.getDefaultToolkit().getScreenSize().height;
		
		setBounds((width - 310) / 2,(height - 260) / 2,310,260);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
	
	void init(){
		boxH = Box.createHorizontalBox();
		boxF = Box.createHorizontalBox();
		
		boxVOne = Box.createVerticalBox();
		boxVTwo = Box.createVerticalBox();
		
		boxVThree = Box.createVerticalBox();
		boxVFour = Box.createVerticalBox();
		
		boxVOne.add(new JLabel("�˻�:"));
		boxVOne.add(Box.createVerticalStrut(5));
		boxVOne.add(new JLabel("����:"));
		
		boxVTwo.add(new JTextField(10));
		boxVOne.add(Box.createVerticalStrut(3));
		boxVTwo.add(new JPasswordField(10));
		
		boxVThree.add(button1 = new JButton("��¼"));
		boxVFour.add(button2 = new JButton("ȡ��"));	
		
		boxH.add(boxVOne);
		boxH.add(Box.createHorizontalStrut(10));
		boxH.add(boxVTwo);
		
		boxF.add(boxVThree);
		boxF.add(Box.createHorizontalStrut(40));
		boxF.add(boxVFour);
		
		add(Box.createVerticalStrut(120));
		add(boxH);
		add(boxF);	
	}
}
