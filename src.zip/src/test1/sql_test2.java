package test1;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class sql_test2 {
	public static void main(String[] srg) {
		String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		// ����JDBC����
		String dbURL = "jdbc:sqlserver://localhost:1434; DatabaseName=2020";
		// ���ӷ����������ݿ�
		String userName = "sa"; // Ĭ���û���
		String userPwd = "123"; // ����
		Connection dbConn = null;
		try {
			Class.forName(driverName);
			dbConn = DriverManager.getConnection(dbURL, userName, userPwd);
			System.out.println("Connection Successful!");
			// ������ӳɹ� ����̨���Connection Successful!
		} catch (Exception e) {
			e.printStackTrace();
		}
		Statement sql;
		ResultSet rs;
		try {
			sql = dbConn.createStatement();
			rs = sql.executeQuery("SELECT * FROM Reports");//SQL��ѯ���
			while (rs.next()) {
				String number = rs.getString(1); 
				String name = rs.getString(2);
				int date = rs.getInt(3);
				float price = rs.getFloat(4);
				String term = rs.getString(5);
				System.out.printf("%s\t", number);// ��ӡnumber��

				System.out.printf("%s\t", name);// name��
				System.out.printf("%d\t", date);// name��
				System.out.printf("%s\t", term);// name��
				System.out.printf("%s\t\n", price);// price��

			}
			dbConn.close();

		} catch (SQLException e) {
			System.out.println(e);
		}
	}

}


