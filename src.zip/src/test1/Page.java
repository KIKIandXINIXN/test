package test1;


import javax.swing.UIManager;
//import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;

public class Page {

	public static void main(String[] args) {
		/*
		try
        {
            org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.launchBeautyEyeLNF();
        }
        catch(Exception e)
        {
            //TODO exception
            System.out.println("�����Ų�Ƥ��ʧ�ܣ�");
        }
		*/
		Login win = new Login();
		win.setVisible(true);
	}

}
