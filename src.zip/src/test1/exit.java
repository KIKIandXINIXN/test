package test1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
 
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
 
/**
 * called another JFrame close this JFrame write by Jimmy.li time:2016/4/6 22:55
 */
 
public class exit {
 
	private static final int WIDTH = 300;
 
	private static final int HEIGHT = 200;
 
	public exit() {
		// ��ͨ��ť�ؼ�
		final JFrame jf = new JFrame("exit");
		jf.setSize(WIDTH, HEIGHT);
		jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		jf.setVisible(true);
		JPanel contentPane = new JPanel();
		jf.setContentPane(contentPane);
 
		// ����������ť�����ӵ��������
 
		JButton close1 = new JButton("�ر�");
		contentPane.add(close1);
 
		close1.addActionListener(new ActionListener() {
 
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				// System.exit(0);
				jf.dispose();
			}
		});
	}
 
	public static void main(String[] args)
 
	{
		new exit();
	}
 
}