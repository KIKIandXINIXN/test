package test1;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
 
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class newframe_exit extends JFrame {

	 
		/**
		 * called another JFrame
		 * close this JFrame
		 * write by Jimmy.li
		 * time:2016/4/6 22:55
		 */
		private static final long serialVersionUID = 1L;
	 
		public newframe_exit() {
			// ��ͨ��ť�ؼ�
			JFrame jf = new JFrame("main");
			Toolkit tk = this.getToolkit();// �õ����ڹ�����
			int width = 650;
			int height = 500;
			Dimension dm = tk.getScreenSize();
			jf.setSize(300, 200);// ���ó���Ĵ�С
			jf.setLocation((int) (dm.getWidth() - width) / 2,
					(int) (dm.getHeight() - height) / 2);// ��ʾ����Ļ����
			jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			jf.setVisible(true);
			JPanel contentPane = new JPanel();
			jf.setContentPane(contentPane);
	 
			// ����������ť�����ҽ���ť���ӵ����������
	 
			JButton another = new JButton("����ҳ��");
	 
			JButton close = new JButton("�ر�");
	 
			contentPane.add(another);
	 
			contentPane.add(close);
	 
			another.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					new exit();
				}
			});
	 
			close.addActionListener(new ActionListener() {
	 
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					System.exit(0);
				}
			});
		}
	 
		public static void main(String[] args)
	 
		{
			new newframe_exit();
	 
		}

}
