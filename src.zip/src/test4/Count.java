package test4;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;

import javax.swing.*;
import javax.swing.border.EmptyBorder;


public class Count extends JDialog implements ActionListener
{
	Myframe myframe;
	
	private final JPanel contentPanel = new JPanel();
	private JPanel panel;
	private JPanel p1;
	private JPanel p2;
	private JRadioButton r1;
	private JRadioButton r2;
	private JTextArea ta;
	private JScrollPane scrollPane;
	private String record;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the dialog.
	 */
	public Count(Myframe myframe1) 
	{
		myframe=myframe1;
		setTitle("ͳ��");
		record=myframe.getrecord();
		setBounds(600, 275, 850, 496);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		ta = new JTextArea();
		ta.setEditable(false);
		ta.setFont(new Font("����", Font.PLAIN, 20));
		contentPanel.add(ta, BorderLayout.CENTER);
		
		scrollPane = new JScrollPane(ta);
		contentPanel.add(scrollPane, BorderLayout.CENTER);
		
		panel = new JPanel();
		contentPanel.add(panel, BorderLayout.SOUTH);
		panel.setLayout(new GridLayout(0, 2, 0, 0));
		
		p1 = new JPanel();
		panel.add(p1);
		
		r1 = new JRadioButton("���μ�¼");
		r1.setFont(new Font("����", Font.PLAIN, 20));
		r1.addActionListener(this);
		p1.add(r1);
		
		p2 = new JPanel();
		panel.add(p2);
		
		r2 = new JRadioButton("��ʷ��¼");
		r2.setFont(new Font("����", Font.PLAIN, 20));
		r2.addActionListener(this);
		p2.add(r2);
		
		ButtonGroup bg=new ButtonGroup();
		bg.add(r1);
		bg.add(r2);
		
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO �Զ����ɵķ������
		if(e.getSource()==r1)
		{
			ta.setText(record);
		}
		if(e.getSource()==r2)
		{
			File file=new File("Transaction record.txt"); //���׼�¼�ļ�
			if(!file.exists())
			{
				JOptionPane.showMessageDialog(this, "û����ʷ���׼�¼", "����", JOptionPane.ERROR_MESSAGE);
			}
			else 
			{
				FileInputStream in;
				try {
					in=new FileInputStream(file);
					byte[] buy=new byte[1000000];
					int len=in.read(buy);
					String text=new String(buy,0,len);
					ta.setText(text);
					in.close();
				} 
				catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
			}
		}
	}

}
