package test4;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class Login extends JFrame implements ActionListener
{
	
	private Connection con;
	private PreparedStatement sql;
	private ResultSet res;
	private String username;
	private String password;
	
	private JPanel contentPane;
	private JTextField t;
	private JPasswordField p;
	private JButton b;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setTitle("��¼");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(625, 375, 650, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel l1 = new JLabel("���ݿ��û���");
		l1.setFont(new Font("����", Font.PLAIN, 20));
		l1.setBounds(120, 80, 150, 30);
		contentPane.add(l1);
		
		t = new JTextField();
		t.setBounds(300, 80, 200, 30);
		t.setText("root");
		contentPane.add(t);
		t.setColumns(10);
		
		JLabel l2 = new JLabel("���ݿ�����");
		l2.setFont(new Font("����", Font.PLAIN, 20));
		l2.setBounds(120, 200, 150, 30);
		contentPane.add(l2);
		
		p = new JPasswordField();
		p.setBounds(300, 200, 200, 30);
		contentPane.add(p);
		
		b = new JButton("��¼");
		b.setBounds(285, 275, 80, 30);
		b.addActionListener(this);
		
		contentPane.add(b);
		setVisible(true);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO �Զ����ɵķ������
		if(e.getSource()==b)
		{
			try {
				username=t.getText();
				password=p.getText();
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/warehouse?&useSSL=false&serverTimezone=UTC",username,password);
				new Myframe(this);
			}
			catch (Exception exception) {
				// TODO: handle exception
				exception.printStackTrace();
				JOptionPane.showMessageDialog(this, "�û������������", "����", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
	
	Connection getcon()
	{
		return con;
	}
	
	PreparedStatement getsql()
	{
		return sql;
	}
	
	ResultSet getres()
	{
		return res;
	}
}
