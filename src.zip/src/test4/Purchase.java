package test4;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.*;
import java.text.DateFormat;
import java.util.Date;

public class Purchase extends JDialog implements ActionListener
{

	private Connection con;
	private PreparedStatement sql;
	private ResultSet res;
	private Myframe myframe;
	
	private final JPanel contentPanel = new JPanel();
	private JTextField t1;
	private JTextField t2;
	private JTextField t4;
	private JTextField t5;
	private JComboBox c3;
	private JButton b6;
	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the dialog.
	 */
	public Purchase(Myframe myframe1) 
	{
		/*
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/warehouse?&useSSL=false&serverTimezone=UTC","root","1044274301");
		} catch (Exception e1) {
			// TODO �Զ����ɵ� catch ��
			e1.printStackTrace();
		}*/
		setTitle("����");
		con=myframe1.getcon();
		sql=myframe1.getsql();
		res=myframe1.getres();
		myframe=myframe1;
		
		setBounds(625, 375, 494, 400);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new GridLayout(6, 1, 0, 0));
		
		JPanel p1 = new JPanel();
		contentPanel.add(p1);
		p1.setLayout(null);
		
		JLabel l1 = new JLabel("����");
		l1.setBounds(37, 16, 72, 25);
		l1.setFont(new Font("����", Font.PLAIN, 20));
		p1.add(l1);
		
		t1 = new JTextField();
		t1.setBounds(137, 16, 300, 25);
		p1.add(t1);
		t1.setColumns(10);
		
		JPanel p2 = new JPanel();
		contentPanel.add(p2);
		p2.setLayout(null);
		
		JLabel l2 = new JLabel("Ʒ��");
		l2.setBounds(37, 16, 72, 25);
		l2.setFont(new Font("����", Font.PLAIN, 20));
		p2.add(l2);
		
		t2 = new JTextField();
		t2.setBounds(137, 16, 300, 25);
		p2.add(t2);
		t2.setColumns(10);
		
		JPanel p3 = new JPanel();
		contentPanel.add(p3);
		p3.setLayout(null);
		
		JLabel l3 = new JLabel("����");
		l3.setBounds(37, 16, 72, 25);
		l3.setFont(new Font("����", Font.PLAIN, 20));
		p3.add(l3);
		
		String item[]= {"ʳƷ","����Ʒ","ҩƷ","ϴ����Ʒ","����"};
		c3 = new JComboBox(item);
		c3.setBounds(137, 16, 300, 25);
		p3.add(c3);
		
		JPanel p4 = new JPanel();
		contentPanel.add(p4);
		p4.setLayout(null);
		
		JLabel l4 = new JLabel("������");
		l4.setBounds(37, 16, 72, 25);
		l4.setFont(new Font("����", Font.PLAIN, 20));
		p4.add(l4);
		
		t4 = new JTextField();
		t4.setBounds(137, 16, 300, 25);
		p4.add(t4);
		t4.setColumns(10);
		
		JPanel p5 = new JPanel();
		contentPanel.add(p5);
		p5.setLayout(null);
		
		JLabel l5 = new JLabel("������");
		l5.setBounds(37, 16, 72, 25);
		l5.setFont(new Font("����", Font.PLAIN, 20));
		p5.add(l5);
		
		t5 = new JTextField();
		t5.setBounds(137, 16, 300, 25);
		p5.add(t5);
		t5.setColumns(10);
		
		JPanel p6 = new JPanel();
		contentPanel.add(p6);
		p6.setLayout(null);
		
		b6 = new JButton("����");
		b6.setFont(new Font("����", Font.PLAIN, 20));
		b6.setBounds(173, 18, 120, 20);
		b6.addActionListener(this);
		p6.add(b6);
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO �Զ����ɵķ������
		if(e.getSource()==b6)
		{
			for(int i=0;i<t4.getText().length();i++)
			{
				int chr=t4.getText().charAt(i);
				if(chr<48||chr>57)
				{
					JOptionPane.showMessageDialog(this, "�����ʽ����ȷ", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
			}
			for(int i=0;i<t5.getText().length();i++)
			{
				int chr=t5.getText().charAt(i);
				if(chr<48||chr>57)
				{
					JOptionPane.showMessageDialog(this, "�����ʽ����ȷ", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
			}
			try {
				String newname=t1.getText();
				String newbrand=t2.getText();
				String newcategory=(String)c3.getSelectedItem();
				String newinprice=t4.getText();
				String newnumber=t5.getText();
				if(newname.trim().equals("")||newbrand.trim().equals("")||newcategory.equals("")||newinprice.equals("")||newnumber.equals("")||newnumber.equals("0"))
				{
					return;
				}
				if (myframe.getbalance()<Integer.valueOf(newinprice)*Integer.valueOf(newnumber)) 
				{
					JOptionPane.showMessageDialog(this, "����", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				String[][] tablevalues=new String[0][4];
				int[] idarray=new int[0]; //��¼����id ����ʾ�ڱ���
				sql=con.prepareStatement("select *from commodity");
				res=sql.executeQuery();
				while(res.next())
				{
					String name=res.getString("name");
					String number=res.getString("number");
					String brand=res.getString("brand");	
					String category=res.getString("category");
					String[] temp1= {name,number,brand,category};
					int tl=tablevalues.length;
					String[][] temp2=new String[tl+1][4];
					int[] temp3=new int[idarray.length+1];
					for(int i=0;i<tl;i++)
					{
						temp2[i]=tablevalues[i];
						temp3[i]=idarray[i];
					}
					temp2[tl]=temp1;
					temp3[tl]=Integer.valueOf(res.getString("id"));
					tablevalues=temp2;
					idarray=temp3;
				}
				int index=-1; //�жϽ��Ļ��Ƿ���� id��ʾ��������
				for(int i=0;i<tablevalues.length;i++)
				{
					if(newname.equals(tablevalues[i][0])&&newbrand.equals(tablevalues[i][2])&&newcategory.equals(tablevalues[i][3]))
					{
						index=i; //�ҵ�ƥ�����Ʒ
						break;
					}
				}
				if(index==-1) //�������� �����ݿ�������
				{
					sql=con.prepareStatement("insert into commodity(name,number,brand,category) value(?,?,?,?)");
					sql.setString(1, newname);
					sql.setString(2, newnumber);
					sql.setString(3, newbrand);
					sql.setString(4, newcategory);
					sql.executeUpdate();
				}
				else //������ �����ݿ��и���
				{
					int id=idarray[index];
					sql=con.prepareStatement("update commodity set number =? where id=?");
					sql.setString(1, String.valueOf(Integer.valueOf(newnumber)+Integer.valueOf(tablevalues[index][1])));
					sql.setString(2, String.valueOf(id));
					sql.executeUpdate();
				}
				File file=new File("Transaction record.txt"); //���׼�¼�ļ�
				if(!file.exists())
				{
					file.createNewFile();
				}
				FileOutputStream out=new FileOutputStream(file,true);
				Date date=new Date();
				DateFormat df = DateFormat.getDateTimeInstance();
				myframe.setbalance(myframe.getbalance()-Integer.valueOf(newinprice)*Integer.valueOf(newnumber));
				String str=df.format(date)+"   ������: "+newcategory+"��   "+newbrand+"��   "+newname+"   "+newnumber+"��   ����: "+newinprice+"Ԫ   ���: "+String.valueOf(myframe.getbalance())+"Ԫ\r\n";
				byte[] buy=str.getBytes();
				out.write(buy);
				out.close();
				myframe.refresh(); //ˢ��������
				myframe.setrecord(myframe.getrecord()+str);
			} 
			catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
	}
}
