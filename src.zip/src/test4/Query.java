package test4;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Query extends JDialog implements ActionListener
{

	private Connection con;
	private PreparedStatement sql;
	private ResultSet res;
	private Myframe myframe;
	
	private final JPanel contentPanel = new JPanel();
	private JTextField t1;
	private JTextField t2;
	private JComboBox c3;
	private JButton b4;
	private JTable table;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the dialog.
	 */
	public Query(Myframe myframe1) 
	{
		setTitle("��ѯ");
		con=myframe1.getcon();
		sql=myframe1.getsql();
		res=myframe1.getres();
		myframe=myframe1;
		table=myframe1.gettable();
		
		setBounds(625, 375, 494, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new GridLayout(4, 1, 0, 0));
		
		JPanel p1 = new JPanel();
		contentPanel.add(p1);
		p1.setLayout(null);
		
		JLabel l1 = new JLabel("����");
		l1.setBounds(37, 16, 72, 25);
		l1.setFont(new Font("����", Font.PLAIN, 20));
		p1.add(l1);
		
		t1 = new JTextField();
		t1.setBounds(120, 16, 300, 25);
		p1.add(t1);
		t1.setColumns(10);
		
		JPanel p2 = new JPanel();
		contentPanel.add(p2);
		p2.setLayout(null);
		
		JLabel l2 = new JLabel("Ʒ��");
		l2.setBounds(37, 16, 72, 25);
		l2.setFont(new Font("����", Font.PLAIN, 20));
		p2.add(l2);
		
		t2 = new JTextField();
		t2.setBounds(120, 16, 300, 25);
		p2.add(t2);
		t2.setColumns(10);
		
		JPanel p3 = new JPanel();
		contentPanel.add(p3);
		p3.setLayout(null);
		
		JLabel l3 = new JLabel("���");
		l3.setBounds(37, 16, 72, 25);
		l3.setFont(new Font("����", Font.PLAIN, 20));
		p3.add(l3);
		
		String item[]= {"","ʳƷ","����Ʒ","ҩƷ","ϴ����Ʒ","����"};
		c3 = new JComboBox(item);
		c3.setBounds(120, 16, 300, 25);
		p3.add(c3);
		
		JPanel p4 = new JPanel();
		contentPanel.add(p4);
		p4.setLayout(null);
		
		b4 = new JButton("��ѯ");
		b4.setFont(new Font("����", Font.PLAIN, 20));
		b4.setBounds(173, 18, 120, 20);
		b4.addActionListener(this);
		p4.add(b4);
		
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO �Զ����ɵķ������
		if(e.getSource()==b4)
		{
			try {
				String newname=t1.getText();
				String newbrand=t2.getText();
				String newcategory=(String)c3.getSelectedItem();
				String[][] tablevalues=new String[0][4];
				int[] idarray=new int[0]; //��¼����id ����ʾ�ڱ���
				sql=con.prepareStatement("select *from commodity");
				res=sql.executeQuery();
				String[] column_names= {"����","����/��","Ʒ��","����"};
				if(newname.equals("")) //�������ؼ��ʹ���ѯ �ɲ�����ֲ���
				{
					if(newbrand.equals(""))
					{
						if(newcategory.equals("")) //�����ؼ��ֶ��յĻ���ʾ����
						{
							myframe.refresh(); //ˢ�±�
						}
						else //���಻Ϊ��
						{
							sql=con.prepareStatement("select *from commodity where category=?");
							sql.setString(1, newcategory);
							res=sql.executeQuery();
							while(res.next())//������ѯ�Ľ�� ���ɱ�
							{
								String name=res.getString("name");				
								String number=res.getString("number");
								String brand=res.getString("brand");	
								String category=res.getString("category");
								String[] temp1= {name,number,brand,category};
								int tl=tablevalues.length;
								String[][] temp2=new String[tl+1][4];
								for(int i=0;i<tl;i++)
								{
									temp2[i]=tablevalues[i];
								}
								temp2[tl]=temp1;
								tablevalues=temp2;
							}
							DefaultTableModel newtableModel=(DefaultTableModel)table.getModel();
							newtableModel.setDataVector(tablevalues, column_names);
							newtableModel.fireTableStructureChanged();
						}
					}
					else
					{
						if(newcategory.equals("")) //Ʒ�Ʋ�Ϊ��
						{
							sql=con.prepareStatement("select *from commodity where brand=?");
							sql.setString(1, newbrand);
							res=sql.executeQuery();
							while(res.next())//������ѯ�Ľ�� ���ɱ�
							{
								String name=res.getString("name");				
								String number=res.getString("number");
								String brand=res.getString("brand");	
								String category=res.getString("category");
								String[] temp1= {name,number,brand,category};
								int tl=tablevalues.length;
								String[][] temp2=new String[tl+1][4];
								for(int i=0;i<tl;i++)
								{
									temp2[i]=tablevalues[i];
								}
								temp2[tl]=temp1;
								tablevalues=temp2;
							}
							DefaultTableModel newtableModel=(DefaultTableModel)table.getModel();
							newtableModel.setDataVector(tablevalues, column_names);
							newtableModel.fireTableStructureChanged();
						}
						else //Ʒ�ƺ����಻Ϊ��
						{
							sql=con.prepareStatement("select *from commodity where category=? and brand=?");
							sql.setString(1, newcategory);
							sql.setString(2, newbrand);
							res=sql.executeQuery();
							while(res.next())//������ѯ�Ľ�� ���ɱ�
							{
								String name=res.getString("name");				
								String number=res.getString("number");
								String brand=res.getString("brand");	
								String category=res.getString("category");
								String[] temp1= {name,number,brand,category};
								int tl=tablevalues.length;
								String[][] temp2=new String[tl+1][4];
								for(int i=0;i<tl;i++)
								{
									temp2[i]=tablevalues[i];
								}
								temp2[tl]=temp1;
								tablevalues=temp2;
							}
							DefaultTableModel newtableModel=(DefaultTableModel)table.getModel();
							newtableModel.setDataVector(tablevalues, column_names);
							newtableModel.fireTableStructureChanged();
						}
					}
				}
				else 
				{
					if(newbrand.equals(""))
					{
						if(newcategory.equals("")) //���Ʋ�Ϊ��
						{
							sql=con.prepareStatement("select *from commodity where name=?");
							sql.setString(1, newname);
							res=sql.executeQuery();
							while(res.next())//������ѯ�Ľ�� ���ɱ�
							{
								String name=res.getString("name");				
								String number=res.getString("number");
								String brand=res.getString("brand");	
								String category=res.getString("category");
								String[] temp1= {name,number,brand,category};
								int tl=tablevalues.length;
								String[][] temp2=new String[tl+1][4];
								for(int i=0;i<tl;i++)
								{
									temp2[i]=tablevalues[i];
								}
								temp2[tl]=temp1;
								tablevalues=temp2;
							}
							DefaultTableModel newtableModel=(DefaultTableModel)table.getModel();
							newtableModel.setDataVector(tablevalues, column_names);
							newtableModel.fireTableStructureChanged();
						}
						else //���ƺ����಻Ϊ��
						{
							sql=con.prepareStatement("select *from commodity where name=? and category=?");
							sql.setString(1, newname);
							sql.setString(2, newcategory);
							res=sql.executeQuery();
							while(res.next())//������ѯ�Ľ�� ���ɱ�
							{
								String name=res.getString("name");				
								String number=res.getString("number");
								String brand=res.getString("brand");	
								String category=res.getString("category");
								String[] temp1= {name,number,brand,category};
								int tl=tablevalues.length;
								String[][] temp2=new String[tl+1][4];
								for(int i=0;i<tl;i++)
								{
									temp2[i]=tablevalues[i];
								}
								temp2[tl]=temp1;
								tablevalues=temp2;
							}
							DefaultTableModel newtableModel=(DefaultTableModel)table.getModel();
							newtableModel.setDataVector(tablevalues, column_names);
							newtableModel.fireTableStructureChanged();
						}
					}
					else 
					{
						if(newcategory.equals("")) //���ƺ�Ʒ�Ʋ�Ϊ��
						{
							sql=con.prepareStatement("select *from commodity where name=? and brand=?");
							sql.setString(1, newname);
							sql.setString(2, newbrand);
							res=sql.executeQuery();
							while(res.next())//������ѯ�Ľ�� ���ɱ�
							{
								String name=res.getString("name");				
								String number=res.getString("number");
								String brand=res.getString("brand");	
								String category=res.getString("category");
								String[] temp1= {name,number,brand,category};
								int tl=tablevalues.length;
								String[][] temp2=new String[tl+1][4];
								for(int i=0;i<tl;i++)
								{
									temp2[i]=tablevalues[i];
								}
								temp2[tl]=temp1;
								tablevalues=temp2;
							}
							DefaultTableModel newtableModel=(DefaultTableModel)table.getModel();
							newtableModel.setDataVector(tablevalues, column_names);
							newtableModel.fireTableStructureChanged();
						}
						else //����Ϊ��
						{
							sql=con.prepareStatement("select *from commodity where name=? and category=? and brand=?");
							sql.setString(1, newname);
							sql.setString(2, newcategory);
							sql.setString(3, newbrand);
							res=sql.executeQuery();
							while(res.next())//������ѯ�Ľ�� ���ɱ�
							{
								String name=res.getString("name");				
								String number=res.getString("number");
								String brand=res.getString("brand");	
								String category=res.getString("category");
								String[] temp1= {name,number,brand,category};
								int tl=tablevalues.length;
								String[][] temp2=new String[tl+1][4];
								for(int i=0;i<tl;i++)
								{
									temp2[i]=tablevalues[i];
								}
								temp2[tl]=temp1;
								tablevalues=temp2;
							}
							DefaultTableModel newtableModel=(DefaultTableModel)table.getModel();
							newtableModel.setDataVector(tablevalues, column_names);
							newtableModel.fireTableStructureChanged();
						}
					}
				}
			} 
			catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
	}
}
