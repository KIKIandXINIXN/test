package test4;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.*;
import java.text.DateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class Myframe extends JFrame implements ActionListener
{
	
	private Connection con;
	private PreparedStatement sql;
	private ResultSet res;
	private DefaultTableModel tableModel;
	private String record="";
	private int balance=0;
	
	private JPanel contentPane;
	private JTable table;
	private JPanel p1;
	private JPanel p2;
	private JPanel p3;
	private JPanel p4;
	private JScrollPane scrollPane;
	private JButton b1;
	private JButton b2;
	private JButton b3;
	private JButton b4;
	private JPanel p5;
	private JButton b5;
	private JPanel south;
	private JPanel p6;
	private JPanel p7;
	private JPanel p8;
	private JLabel l6;
	private JTextField t6;
	private JTextField t7;
	private JButton b7;
	private JTextField t8;
	private JButton b8;
	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public Myframe(Login log)
	{
		setTitle("���й���ϵͳ");
		log.setVisible(false);
		con=log.getcon();
		res=log.getres();
		sql=log.getsql();
		File file=new File("Transaction record.txt"); //���׼�¼�ļ�
		if(file.exists())
		{
			String regex="[0-9]+";
			Pattern pattern=Pattern.compile(regex);
			FileInputStream in;
			try {
				in=new FileInputStream(file);
				byte[] buy=new byte[1000000];
				int len=in.read(buy);
				String text=new String(buy,0,len);
				Matcher matcher=pattern.matcher(text);
				while(matcher.find())
				{
					balance=Integer.valueOf(text.substring(matcher.start(), matcher.end()));
				}
				in.close();
			} 
			catch (Exception e1) {
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}
		}
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(150, 100, 1200, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JPanel center = new JPanel();
		contentPane.add(center, BorderLayout.CENTER);
		center.setLayout(new BorderLayout(0, 0));
		
		String[] column_names= {"����","����/��","Ʒ��","����"};
		String[][] tablevalues=new String[0][4];
		
		try {
			
			sql=con.prepareStatement("select *from commodity");
			res=sql.executeQuery();
			while(res.next())//������ѯ�Ľ�� ���ɱ�
			{
				String name=res.getString("name");				
				String number=res.getString("number");
				String brand=res.getString("brand");	
				String category=res.getString("category");
				String[] temp1= {name,number,brand,category};
				int tl=tablevalues.length;
				String[][] temp2=new String[tl+1][4];
				for(int i=0;i<tl;i++)
				{
					temp2[i]=tablevalues[i];
				}
				temp2[tl]=temp1;
				tablevalues=temp2;
			}
		} 
		catch (Exception e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		
		tableModel=new DefaultTableModel(tablevalues, column_names); //���ö�̬ģʽ�ı�
		table=new JTable(tableModel);
		table.setEnabled(false);
		
		table.setFont(new Font("����", Font.PLAIN, 30));
		table.setRowHeight(30);
		
		center.add(table, BorderLayout.CENTER);
		
		scrollPane = new JScrollPane(table);
		center.add(scrollPane, BorderLayout.CENTER);
		
		JPanel east = new JPanel();
		east.setPreferredSize(new Dimension(150, 100));
		contentPane.add(east, BorderLayout.EAST);
		east.setLayout(new GridLayout(5, 1, 0, 0));
		
		p1 = new JPanel();
		east.add(p1);
		p1.setLayout(new BorderLayout(0, 0));
		
		b1 = new JButton("����");
		b1.addActionListener(this);
		p1.add(b1, BorderLayout.CENTER);
		
		p2 = new JPanel();
		east.add(p2);
		p2.setLayout(new BorderLayout(0, 0));
		
		b2 = new JButton("����");
		b2.addActionListener(this);
		p2.add(b2, BorderLayout.CENTER);
		
		p3 = new JPanel();
		east.add(p3);
		p3.setLayout(new BorderLayout(0, 0));
		
		b3 = new JButton("��ѯ");
		b3.addActionListener(this);
		p3.add(b3, BorderLayout.CENTER);
		
		p4 = new JPanel();
		east.add(p4);
		p4.setLayout(new BorderLayout(0, 0));
		
		b4 = new JButton("���׼�¼");
		b4.addActionListener(this);
		p4.add(b4, BorderLayout.CENTER);
		
		p5 = new JPanel();
		east.add(p5);
		p5.setLayout(new BorderLayout(0, 0));
		
		b5 = new JButton("ˢ��");
		b5.addActionListener(this);
		p5.add(b5, BorderLayout.CENTER);
		
		south = new JPanel();
		south.setPreferredSize(new Dimension(50, 50));
		contentPane.add(south, BorderLayout.SOUTH);
		south.setLayout(new GridLayout(0, 3, 0, 0));
		
		p6 = new JPanel();
		south.add(p6);
		p6.setLayout(null);
		
		l6 = new JLabel("���/Ԫ");
		l6.setBounds(50, 16, 72, 18);
		p6.add(l6);
		
		t6 = new JTextField();
		t6.setText(String.valueOf(balance));
		t6.setEditable(false);
		t6.setBounds(124, 13, 227, 24);
		p6.add(t6);
		t6.setColumns(10);
		
		p7 = new JPanel();
		south.add(p7);
		p7.setLayout(null);
		
		t7 = new JTextField();
		t7.setBounds(57, 13, 132, 24);
		p7.add(t7);
		t7.setColumns(10);
		
		b7 = new JButton("��Ǯ");
		b7.setBounds(230, 12, 113, 25);
		b7.addActionListener(this);
		p7.add(b7);
		
		p8 = new JPanel();
		south.add(p8);
		p8.setLayout(null);
		
		t8 = new JTextField();
		t8.setBounds(57, 13, 132, 24);
		p8.add(t8);
		t8.setColumns(10);
		
		b8 = new JButton("ȡǮ");
		b8.setBounds(230, 12, 113, 25);
		b8.addActionListener(this);
		p8.add(b8);
		setVisible(true);
	}
	
	void refresh()
	{
		String[] column_names= {"����","����/��","Ʒ��","����"};
		String[][] tablevalues=new String[0][4];
		
		try {
			sql=con.prepareStatement("select *from commodity");
			res=sql.executeQuery();
			while(res.next())//������ѯ�Ľ�� ���ɱ�
			{
				String name=res.getString("name");				
				String number=res.getString("number");
				String brand=res.getString("brand");	
				String category=res.getString("category");
				String[] temp1= {name,number,brand,category};
				int tl=tablevalues.length;
				String[][] temp2=new String[tl+1][4];
				for(int i=0;i<tl;i++)
				{
					temp2[i]=tablevalues[i];
				}
				temp2[tl]=temp1;
				tablevalues=temp2;
			}
			DefaultTableModel newtableModel=(DefaultTableModel)table.getModel();
			newtableModel.setDataVector(tablevalues, column_names);
			newtableModel.fireTableStructureChanged();
		} 
		catch (Exception e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) //��ťʱ�������
	{
		if(e.getSource()==b1)
		{
			new Purchase(this);
		}
		if(e.getSource()==b2)
		{
			new Sell(this);
		}
		if(e.getSource()==b3)
		{
			new Query(this);
		}
		if(e.getSource()==b4)
		{
			new Count(this);
		}
		if(e.getSource()==b5)
		{
			refresh();
		}
		if(e.getSource()==b7)
		{
			if(t7.getText().equals("")||t7.getText().equals("0"))
			{
				return;
			}
			for(int i=0;i<t7.getText().length();i++)
			{
				int chr=t7.getText().charAt(i);
				if(chr<48||chr>57)
				{
					JOptionPane.showMessageDialog(this, "�����ʽ����ȷ", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
			}
			balance+=Integer.valueOf(t7.getText());
			t6.setText(String.valueOf(balance));
			Date date=new Date();
			DateFormat df = DateFormat.getDateTimeInstance();
			String str=df.format(date)+"   ����: "+t7.getText()+"Ԫ   ���: "+String.valueOf(balance)+"Ԫ\r\n";
			record+=str;
			try {
				File file=new File("Transaction record.txt"); //���׼�¼�ļ�
				if(!file.exists())
				{
					file.createNewFile();
				}
				FileOutputStream out=new FileOutputStream(file,true);
				byte[] buy=str.getBytes();
				out.write(buy);
				out.close();
			} 
			catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		if(e.getSource()==b8)
		{
			if(t8.getText().equals("")||t8.getText().equals("0"))
			{
				return;
			}
			for(int i=0;i<t7.getText().length();i++)
			{
				int chr=t7.getText().charAt(i);
				if(chr<48||chr>57)
				{
					JOptionPane.showMessageDialog(this, "�����ʽ����ȷ", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
			}
			if(balance<Integer.valueOf(t8.getText()))
			{
				JOptionPane.showMessageDialog(this, "����", "����", JOptionPane.ERROR_MESSAGE);
				return;
			}
			balance-=Integer.valueOf(t8.getText());
			t6.setText(String.valueOf(balance));
			Date date=new Date();
			DateFormat df = DateFormat.getDateTimeInstance();
			String str=df.format(date)+"   ȡ��: "+t8.getText()+"Ԫ   ���: "+String.valueOf(balance)+"Ԫ\r\n";
			record+=str;
			try {
				File file=new File("Transaction record.txt"); //���׼�¼�ļ�
				if(!file.exists())
				{
					file.createNewFile();
				}
				FileOutputStream out=new FileOutputStream(file,true);
				byte[] buy=str.getBytes();
				out.write(buy);
				out.close();
			} 
			catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
	}
	
	void setbalance(int balance)
	{
		this.balance=balance;
		t6.setText(String.valueOf(balance));
	}
	
	void setrecord(String record)
	{
		this.record=record;
	}
	
	int getbalance()
	{
		return balance;
	}
	
	String getrecord()
	{
		return record;
	}
	
	Connection getcon()
	{
		return con;
	}
	
	PreparedStatement getsql()
	{
		return sql;
	}
	
	ResultSet getres()
	{
		return res;
	}
	
	JTable gettable()
	{
		return table;
	}
}
