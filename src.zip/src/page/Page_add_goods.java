package page;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.UIManager;

import listen.Listen_page_add_goods.Listen_text_month_or_day_date_of_manufacture;
import listen.Listen_page_add_goods.Listen_text_year_date_of_manufacture;


public class Page_add_goods extends JFrame{
	JLabel label_id,label_name,label_num,label_price,label_date,label_year,label_month,label_day,label_expiration_day;
	public JTextField text_id,text_name,text_num,text_price,text_year,text_month,text_day,text_expiration_day; 
	public JButton jButton_confirm,jButton_cancel;
	
	public Page_add_goods() {
		//��������
		JFrame window = new JFrame("������Ʒ");
		window.setBounds(0, 0, 400, 450);
		window.setLocationRelativeTo(null);		
		window.setResizable(false);//�ô��ڴ�С���ɸı�  
		window.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);	
		window.add(getContentPane());
		getContentPane().setLayout(null);

		label_id = new JLabel("��Ʒ��ţ�");
		label_id.setBounds(85, 37, 87, 22);
		getContentPane().add(label_id);		
		text_id = new JTextField();//�����
		text_id.setBounds(147, 37, 142, 21);
		getContentPane().add(text_id);
		text_id.setColumns(10);
		
		label_name = new JLabel("��Ʒ����");
		label_name.setBounds(85, 89, 87, 22);
		getContentPane().add(label_name);		
		text_name = new JTextField();//�����
		text_name.setColumns(10);
		text_name.setBounds(147, 89, 142, 21);
		getContentPane().add(text_name);
		
		label_num = new JLabel("������");
		label_num.setBounds(85, 142, 87, 22);
		getContentPane().add(label_num);		
		text_num = new JTextField();//�����
		text_num.setColumns(10);
		text_num.setBounds(147, 143, 142, 21);
		getContentPane().add(text_num);
		
		label_price = new JLabel("���ۣ�");
		label_price.setBounds(85, 194, 87, 22);
		getContentPane().add(label_price);		
		text_price = new JTextField(); //�����
		text_price.setColumns(10);
		text_price.setBounds(147, 195, 142, 21);
		getContentPane().add(text_price);
		
		label_date = new JLabel("�������ڣ�");
		label_date.setBounds(85, 246, 87, 22);
		getContentPane().add(label_date);		 
		
		//���������-��-�����Ӽ����������Ӽ����¼�
		Listen_text_year_date_of_manufacture police4 = new Listen_text_year_date_of_manufacture();
		Listen_text_month_or_day_date_of_manufacture police2 = new Listen_text_month_or_day_date_of_manufacture();
		
		label_year = new JLabel("��");
		label_year.setBounds(195, 246, 87, 22);
		text_year = new JTextField(4);//�����
		text_year.setColumns(10);
		text_year.setBounds(147, 246, 42, 21);
		text_year.addKeyListener(police4);
		text_year.addFocusListener(police4);
		getContentPane().add(text_year);	
		getContentPane().add(label_year);
		
		label_month = new JLabel("��");
		label_month.setBounds(240, 246, 87, 22);
		text_month = new JTextField(2);//�����
		text_month.setColumns(10);
		text_month.setBounds(215, 246, 21, 21);
		text_month.addKeyListener(police2);
		text_month.addFocusListener(police2);
		getContentPane().add(text_month);		
		getContentPane().add(label_month);
		
		label_day = new JLabel("��");
		label_day.setBounds(285, 246, 87, 22);
		text_day = new JTextField(2);//�����
		text_day.setColumns(10);
		text_day.setBounds(260, 246, 21, 21);
		text_day.addKeyListener(police2);
		text_day.addFocusListener(police2);
		getContentPane().add(text_day);
		getContentPane().add(label_day);
		
		label_expiration_day = new JLabel("������������");
		label_expiration_day.setBounds(85, 291, 87, 22);
		getContentPane().add(label_expiration_day);
		text_expiration_day = new JTextField(); //�����
		text_expiration_day.setColumns(10);
		text_expiration_day.setBounds(160, 291, 142, 21);
		getContentPane().add(text_expiration_day);
		
		jButton_confirm = new JButton("ȷ��");
		jButton_confirm.setBounds(78, 342, 93, 35);		
		getContentPane().add(jButton_confirm);
		
		jButton_cancel = new JButton("ȡ��");
		jButton_cancel.setBounds(208, 342, 93, 35);
		getContentPane().add(jButton_cancel);
		jButton_cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				window.dispose();
			}
		});

		
		window.setVisible(true);
	}
	
	public static void main(String[] args) {
		Open_page openpage = new Open_page();
		openpage.set_page_ui_win(); //����ҳ��۸�
		openpage.page_add_goods(); //�򿪵�½����
	}
	

}
