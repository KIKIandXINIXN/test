package page;


import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import listen.listen_page_choice_mode.Listen_page_choice_mode_button_to_manage;
import listen.listen_page_choice_mode.Listen_page_choice_mode_button_to_sell;



public class Page_choice_mode extends JFrame{

	public JButton button_to_manage,button_to_sell;
	public JFrame window;
	
	public Page_choice_mode() {
		window = new JFrame("ѡ��ģʽ");
		window.setBounds(0, 0, 720, 500);
		window.setLocationRelativeTo(null);
		window.setResizable(false);//�ô��ڴ�С���ɸı�  
							
		
		JPanel jp = new JPanel() {
            protected void paintComponent(Graphics g) {
                ImageIcon icon = new ImageIcon(getClass().getResource("../img/1.jpg"));
                Image img = icon.getImage();
                g.drawImage(img, 0, 0, icon.getIconWidth(), icon.getIconHeight(), icon.getImageObserver());
            }
        };

        window.add(jp);
        jp.setLayout(null);
        
		button_to_manage = new JButton("�������");	
		button_to_manage.setFont(new Font("����",0,40));
		button_to_manage.setBackground(new Color(0,206,209));
		//button_to_manage.setContentAreaFilled(false); //͸��
		button_to_manage.setBorder(BorderFactory.createLoweredBevelBorder()); //���ð������İ�ť
		button_to_manage.setForeground(new Color(0,206,209)); //����ǰ��ɫ/������ɫ
		//button_to_manage.setBorder(BorderFactory.createRaisedBevelBorder()); //����͹�����İ�ť
		//button_to_manage.setBorderPainted(false); //ȥ����ť�ı߿������
		button_to_manage.setBounds(70, 71, 250, 300);

		button_to_sell = new JButton("��Ʒ����");		
		button_to_sell.setFont(new Font("����",0,40));
		button_to_sell.setBackground(new Color(205,155,155));
		button_to_sell.setForeground(new Color(205,155,155)); //����ǰ��ɫ/������ɫ
		button_to_sell.setBorder(BorderFactory.createLoweredBevelBorder());
		button_to_sell.setBounds(385,71,250,300); 

		//���Ӱ�ť�ļ����� 
		Listen_page_choice_mode_button_to_manage listen_page_choice_mode_button_to_manage = new Listen_page_choice_mode_button_to_manage();
		listen_page_choice_mode_button_to_manage.set_page_choice_mode(this);
		button_to_manage.addActionListener(listen_page_choice_mode_button_to_manage);
		
		Listen_page_choice_mode_button_to_sell listen_page_choice_mode_button_to_sell = new Listen_page_choice_mode_button_to_sell();
		listen_page_choice_mode_button_to_sell.set_page_choice_mode(this);
		button_to_sell.addActionListener(listen_page_choice_mode_button_to_sell);

		jp.add(button_to_manage);
		jp.add(button_to_sell);
		
		window.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);	
		window.setVisible(true);
	}
	

		public static void main(String[] args) {		
			Open_page openpage = new Open_page();
			openpage.set_page_ui_win(); //����ҳ��۸�
			openpage.page_choice_mode(); 
		}
		
		
		
		

}
