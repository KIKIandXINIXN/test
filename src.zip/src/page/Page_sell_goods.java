package page;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

import listen.Listen_page_sell_goods.Listen_button_to_manage;

public class Page_sell_goods extends JFrame{
	//���������
	JButton button_to_add,button_to_empty,button_to_sale,button_to_alter,button_to_delete;
	JTextField text_goods_id,text_total;
	JLabel label_goodsid,label_total;
	JTable table_sell;
	public JFrame window;
	public Button_circle button_to_manage;
	
	//�������ݱ���С�Ĳ���
	int v=ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
	int h=ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
	
	public String[] tablehead;
	public String[][] tablecontent;
	
	public Page_sell_goods() {
		window = new JFrame("����ҳ��");
		window.setBounds(0, 0, 720, 500);
		window.setLocationRelativeTo(null);
		window.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		//window.add(getContentPane());
		window.setResizable(false);//�ô��ڴ�С���ɸı�  
		//getContentPane().setLayout(null);
		
		ImageIcon icon = new ImageIcon(getClass().getResource("../img/ic_s.png")); // ��ȡͼƬ����
		window.setIconImage(icon.getImage());  // ����ͼ��
		
		
		JPanel jp = new JPanel() {
            protected void paintComponent(Graphics g) {
                ImageIcon icon = new ImageIcon(getClass().getResource("../img/1.jpg"));
                Image img = icon.getImage();
                g.drawImage(img, 0, 0, icon.getIconWidth(), icon.getIconHeight(), icon.getImageObserver());
            }
        };

        window.add(jp);
        jp.setLayout(null);
		
		
		label_goodsid = new JLabel("��Ʒ��ţ�");
		label_goodsid.setBounds(10, 15, 112, 32);
		jp.add(label_goodsid);
		
		text_goods_id = new JTextField();
		text_goods_id.setBounds(75, 15, 182, 35);
		jp.add(text_goods_id);
		text_goods_id.setColumns(10);
		
		button_to_add = new JButton("����");
		button_to_add.setBounds(270, 18, 80, 25);		
		jp.add(button_to_add);
		
		button_to_alter = new JButton("�޸���Ʒ");
		button_to_alter.setBounds(370, 18, 100, 25);		
		jp.add(button_to_alter);
		
		button_to_delete = new JButton("ɾ����Ʒ");
		button_to_delete.setBounds(480, 18, 100, 25);		
		jp.add(button_to_delete);
		
		button_to_empty = new JButton("���");
		button_to_empty.setBounds(600, 18, 80, 25);		
		jp.add(button_to_empty);
				
		table_sell = new JTable();
		table_sell.setEnabled(true);//���ñ���Ϊ���ɱ༭
		JScrollPane jsp_table_sell=new JScrollPane(table_sell,v,h);
		jsp_table_sell.setBounds(10, 60, 660, 320);
		jp.add(jsp_table_sell);
		
		button_to_manage = new Button_circle(">>�������<<");
		button_to_manage.setBounds(20, 400, 120, 40);
		button_to_manage.setBackground(new Color(224,238,238));	
		button_to_manage.setFont(new Font("����", 1,14));
		jp.add(button_to_manage);

		Listen_button_to_manage listen_button_to_manage = new Listen_button_to_manage();
		listen_button_to_manage.set_page_sell_goods(this);
		button_to_manage.addActionListener(listen_button_to_manage);
		
		label_total = new JLabel("�ܼ۸�");
		label_total.setBounds(245, 402, 112, 32);
		jp.add(label_total);
		
		text_total = new JTextField();
		text_total.setBounds(300, 400, 142, 40);
		jp.add(text_total);
		text_total.setColumns(10);
			
		button_to_sale = new JButton("ȷ���۳�");
		button_to_sale.setBounds(560, 400, 100, 40);
		jp.add(button_to_sale);
		
		window.setVisible(true);
		
	}
	
	public static void main(String[] args) {
		Open_page openpage = new Open_page();
		openpage.set_page_ui_win(); //����ҳ��۸�
		openpage.page_sell_goods(); // �򿪽���
		
	}
}
