package page;

import javax.swing.*;

import listen.Listen_button_quit;

import java.awt.*;


public class Page_Login extends JFrame{
	public JButton button1,button2;
	public JLabel label1,label2;
	public JTextField text1 = new JTextField(10);
	public JPasswordField password1 = new JPasswordField(10);
	
			
	public Page_Login(){
		setTitle("��¼");
		setLocationRelativeTo(null);//�ô�������Ļ�м���ʾ
		setResizable(false);//�ô��ڴ�С���ɸı�   
		setLayout(null);//���ò��ֹ�����Ϊnull
		
		int width = Toolkit.getDefaultToolkit().getScreenSize().width;
	    int height = Toolkit.getDefaultToolkit().getScreenSize().height;
	    
	    label1 = new JLabel("�˻� :");
	    label1.setBounds(70, 50, 112, 32);
	    add(label1);
	    label2 = new JLabel("���� :");
	    label2.setBounds(70, 80, 112, 32);
	    add(label2);
	    
	    text1 = new JTextField();
		text1.setBounds(110, 55, 120, 26);
		getContentPane().add(text1);
		
		password1 = new JPasswordField();
		password1.setBounds(110, 85, 120, 26);
		getContentPane().add(password1);
	    
	    button1 = new JButton("��¼");
	    button1.setBounds(75, 140, 60, 30);
	    button2 = new JButton("ȡ��");
	    button2.setBounds(165, 140, 60, 30);	    
	    add(button1);
	    add(button2);

	    button2.addActionListener(new Listen_button_quit());
	    
		setBounds((width - 310) / 2,(height - 260) / 2,310,260);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setVisible(true);
	}
	
	public static void main(String[] args) {
		Open_page openpage = new Open_page();
		openpage.set_page_ui_win(); //����ҳ��۸�
		openpage.page_login(); //�򿪵�½����
	}
	
}



