package page;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import listen.Listen_page_add_goods.Listen_text_month_or_day_date_of_manufacture;
import listen.Listen_page_add_goods.Listen_text_year_date_of_manufacture;
import sql.Sql_select;

public class Page_alter_goods extends JFrame{
	JLabel label_id,label_name,label_num,label_price,label_date,label_year,label_month,label_day,label_expiration_day;
	public JTextField text_name,text_num,text_price,text_year,text_month,text_day,text_expiration_day; 
	public JLabel label_id_data;
	public JButton jButton_confirm,jButton_cancel;
	public JFrame window;
	
	String [][] message; //��¼��Ʒ��Ϣ
	String goods_id1;//��¼������
	String goods_id2;//��¼��Ʒ���
	int row;//��¼��Ʒ����
	
	public Page_alter_goods() {
		//��������
		window = new JFrame("�޸���Ʒ");
		window.setBounds(0, 0, 400, 450);
		window.setLocationRelativeTo(null);		
		window.setResizable(false);//�ô��ڴ�С���ɸı�  
		window.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);	
		window.add(getContentPane());
		getContentPane().setLayout(null);
		
		label_id = new JLabel("��Ʒ��ţ�");
		label_id.setBounds(85, 37, 87, 22);
		getContentPane().add(label_id);
		label_id_data = new JLabel(); //�������
		label_id_data.setBounds(147, 37, 142, 21);
		getContentPane().add(label_id_data);
		
		label_name = new JLabel("��Ʒ����");
		label_name.setBounds(85, 89, 87, 22);
		getContentPane().add(label_name);		
		text_name = new JTextField();//�����
		text_name.setColumns(10);
		text_name.setBounds(147, 89, 142, 21);
		getContentPane().add(text_name);
		
		label_num = new JLabel("������");
		label_num.setBounds(85, 142, 87, 22);
		getContentPane().add(label_num);		
		text_num = new JTextField();//�����
		text_num.setColumns(10);
		text_num.setBounds(147, 143, 142, 21);
		getContentPane().add(text_num);
		
		label_price = new JLabel("���ۣ�");
		label_price.setBounds(85, 194, 87, 22);
		getContentPane().add(label_price);		
		text_price = new JTextField();//�����
		text_price.setColumns(10);
		text_price.setBounds(147, 195, 142, 21);
		getContentPane().add(text_price);
		
		label_date = new JLabel("�������ڣ�");
		label_date.setBounds(85, 246, 87, 22);
		getContentPane().add(label_date);
		
		// ���������-��-�����Ӽ����������Ӽ����¼�
		Listen_text_year_date_of_manufacture police4 = new Listen_text_year_date_of_manufacture();
		Listen_text_month_or_day_date_of_manufacture police2 = new Listen_text_month_or_day_date_of_manufacture();

		label_year = new JLabel("��");
		label_year.setBounds(195, 246, 87, 22);
		text_year = new JTextField(4);// �����
		text_year.setColumns(10);
		text_year.setBounds(147, 246, 42, 21);
		text_year.addKeyListener(police4);
		text_year.addFocusListener(police4);
		getContentPane().add(text_year);
		getContentPane().add(label_year);

		label_month = new JLabel("��");
		label_month.setBounds(240, 246, 87, 22);
		text_month = new JTextField(2);// �����
		text_month.setColumns(10);
		text_month.setBounds(215, 246, 21, 21);
		text_month.addKeyListener(police2);
		text_month.addFocusListener(police2);
		getContentPane().add(text_month);
		getContentPane().add(label_month);

		label_day = new JLabel("��");
		label_day.setBounds(285, 246, 87, 22);
		text_day = new JTextField(2);// �����
		text_day.setColumns(10);
		text_day.setBounds(260, 246, 21, 21);
		text_day.addKeyListener(police2);
		text_day.addFocusListener(police2);
		getContentPane().add(text_day);
		getContentPane().add(label_day);
		
		label_expiration_day = new JLabel("������������");
		label_expiration_day.setBounds(85, 291, 87, 22);
		getContentPane().add(label_expiration_day);		
		text_expiration_day = new JTextField();//�����
		text_expiration_day.setColumns(10);
		text_expiration_day.setBounds(160, 291, 142, 21);
		getContentPane().add(text_expiration_day);
		
		
		jButton_confirm = new JButton("ȷ��");
		jButton_confirm.setBounds(78, 342, 93, 35);		
		getContentPane().add(jButton_confirm);
		
				
		jButton_cancel = new JButton("ȡ��");
		jButton_cancel.setBounds(208, 342, 93, 35);
		getContentPane().add(jButton_cancel);
		jButton_cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("why");
				window.dispose();
			}
		});
			
		window.setVisible(true);
	}
	
	public void add_message() {
		// ������Ϣ
		Sql_select sql_select = new Sql_select();
		sql_select.setSQL("select ��Ʒ���,��Ʒ����,����,����,\r\n"
				+ "		Year(����ʱ��) as ��,\r\n"
				+ "		Month(����ʱ��) as ��,\r\n"
				+ "		Day(����ʱ��) as ��,\r\n"
				+ "		����������\r\n"
				+ "from Goods where ������ = '" + goods_id1 +"'");
		message = sql_select.getRecord();

		if (check_id()) {
			System.out.println("��Ʒ���ڣ�");
			label_id_data.setText(message[row][0].trim());
			text_name.setText(message[row][1].trim());
			text_num.setText(message[row][2].trim());
			text_price.setText(message[row][3].trim());
			text_year.setText(message[row][4].trim());
			text_month.setText(message[row][5].trim());
			text_day.setText(message[row][6].trim());
			text_expiration_day.setText(message[row][7].trim());
		} else {
			JOptionPane.showMessageDialog(this, "û�и���Ʒ��");
			label_id_data.setText(null);
			text_name.setText(null);
			text_num.setText(null);
			text_price.setText(null);
			text_year.setText(null);
			text_month.setText(null);
			text_day.setText(null);
			text_expiration_day.setText(null);
		}
	}
	
	public void set_goods_id1(String goods_id1) {
		this.goods_id1 = goods_id1;
	}
	
	public void set_goods_id2(String goods_id2) {
		this.goods_id2 = goods_id2;
	}
	
	public boolean check_id() {
		for(int i = 0;i < message.length;i++) {
			if(message[i][0].trim().equals(goods_id2)) {
				row = i;
				return true;
			}
		}
		return false;
	}
	

}

