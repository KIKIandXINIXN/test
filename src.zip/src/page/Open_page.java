package page;

import java.awt.Color;
import java.awt.Font;

import javax.swing.UIManager;

import listen.Listen_button_login;
import listen.Listen_page_add_goods.Listen_page_add_goods_button_confirm;
import listen.Listen_page_add_goods.Listen_page_add_goods_text_id;
import listen.Listen_page_alter_goods.Listen_page_alter_goods_button_confirm;
import sql.Sql_select;

//��������ҳ��

public class Open_page {
	Page_manage_goods page_manage_goods;
	String goods_id1;//��¼������
	String goods_id2;//��¼��Ʒ���
	
	public void set_page_ui_win() {
		try {
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
			//UIManager.setLookAndFeel("ch.randelshofer.quaqua.QuaquaLookAndFeel");
		} catch (Exception ex) {
			System.err.println("����Ƥ��ʧ��!!!");
		}
	}
	
	public void set_page_ui_window() {
		try {
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		} catch (Exception ex) {
			System.err.println("����Ƥ��ʧ��!!!");
		}
	}
	

	public void page_choice_mode() {
		Page_choice_mode page_choice_mode = new Page_choice_mode();
	}
	
	public void page_login() { //�򿪵�½����
		Page_Login login = new Page_Login();
		
		Listen_button_login login_lsiten =new Listen_button_login();
		
		login_lsiten.set_login(login);
		login.button1.addActionListener(login_lsiten);
	}
	
	public void page_manage_goods() {  //�򿪻����������
		Page_manage_goods manage_goods = new Page_manage_goods();//Ϊ��ת�Ľ���

	}
	
	public void page_sell_goods() {  //�����۽���
		Page_sell_goods page_sell_goods = new Page_sell_goods();//Ϊ��ת�Ľ���

	}
	

	public void page_add_goods() { //�����ӻ������
		String [][] message;
		Page_add_goods page_add_goods = new Page_add_goods(); 
		
		Sql_select sql_select = new Sql_select();
		sql_select.setSQL("select ��Ʒ���,��Ʒ����,����,����,\r\n"
				+ "		Year(����ʱ��) as ��,\r\n"
				+ "		Month(����ʱ��) as ��,\r\n"
				+ "		Day(����ʱ��) as ��,\r\n"
				+ "		����������\r\n"
				+ "from Goods");
		message = sql_select.getRecord();
		
		//���Ӽ�����-��������
		Listen_page_add_goods_text_id listen_text_id = new Listen_page_add_goods_text_id();
		listen_text_id.set_message(message);
		listen_text_id.set_page_add_goods(page_add_goods);
		page_add_goods.text_id.addActionListener(listen_text_id);
		
		//���Ӽ�����-ȷ�ϰ�ť
		Listen_page_add_goods_button_confirm listen_jButton_confirm = new Listen_page_add_goods_button_confirm();
		listen_jButton_confirm.set_page_add_goods(page_add_goods);
		listen_jButton_confirm.set_page_manage_goods(page_manage_goods);
		page_add_goods.jButton_confirm.addActionListener(listen_jButton_confirm);

	}
	
	public void page_alter_goods() { //���޸Ļ������

		Page_alter_goods page_alter_goods = new Page_alter_goods();
		page_alter_goods.set_goods_id1(goods_id1);
		page_alter_goods.set_goods_id2(goods_id2);
		page_alter_goods.add_message();
		
		//���Ӽ�����-ȷ�ϰ�ť
		Listen_page_alter_goods_button_confirm listen_page_alter_goods_button_confirm = new Listen_page_alter_goods_button_confirm();
		listen_page_alter_goods_button_confirm.set_page_alter_goods(page_alter_goods);
		listen_page_alter_goods_button_confirm.set_page_manage_goods(page_manage_goods);
		listen_page_alter_goods_button_confirm.set_goods_id1(goods_id1);
		listen_page_alter_goods_button_confirm.set_goods_id2(goods_id2);
		page_alter_goods.jButton_confirm.addActionListener(listen_page_alter_goods_button_confirm);
		
	}
	
	
	public void set_goods_id1(String goods_id1) {
		this.goods_id1 = goods_id1;
	}
	
	public void set_goods_id2(String goods_id2) {
		this.goods_id2 = goods_id2;
	}
	
	public void set_page_manage_goods(Page_manage_goods page_manage_goods) {
		this.page_manage_goods = page_manage_goods;
	}
	
}
